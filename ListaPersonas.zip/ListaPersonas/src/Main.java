import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner entrada=new Scanner(System.in);

        List<Persona> lista=new ArrayList<>();
        boolean salir=false;

        while(!salir){
            menu();
            try{
                salir=ejecutarOperacion(entrada, lista);
            }catch(Exception e){
                System.out.println("Ocurrio un error " + e.getMessage());
            }


            System.out.println();

        }//fin while


    }//fin main

    private static boolean ejecutarOperacion(Scanner entrada, List<Persona> lista) {
        var opcion = Integer.parseInt(entrada.nextLine());
        boolean salir=false;
        switch (opcion){
            case 1 ->{
                System.out.print("Nombre de usuario: ");
                var nombre = entrada.nextLine();
                System.out.print("Telefono: ");
                var tel= entrada.nextLine();
                System.out.println("Email: ");
                var email=entrada.nextLine();

                Persona person =new Persona(nombre, tel, email);
                lista.add(person);
                System.out.print("La lista tiene: "+lista.size());
                break;
            }
            case 2->{
                System.out.println("Listado de personas");
                lista.forEach(System.out::println);
            }
            case 3->{
                System.out.println("Muchas gracias");
                salir=true;
                return salir;
            }
            default -> System.out.println("Opcion erronea: "+opcion);

        }//fin switch

        return salir;

    }//fin ejecutarOperacion

    private static void menu() {
        System.out.println("***Lista de empleados*** \n1. Agregar \n2. Listar \n3. Salir ");
        System.out.print("Elige una opcion: ");
    }//fin menu


}//fin class