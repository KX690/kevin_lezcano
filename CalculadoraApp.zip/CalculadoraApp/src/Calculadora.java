import java.util.Scanner;

public class Calculadora {
    public static void main(String[] args) {

        Scanner entrada=new Scanner(System.in);
        float operando1=0;
        float operando2=0;
        float resultado;
        int a=0;
        String condicion="si";
        while(condicion.equalsIgnoreCase("si")) {
            while (a < 1 || a > 5) {


                try {
                    menu();
                    a = Integer.parseInt(entrada.nextLine());
                } catch (Exception e) {
                    System.out.println("Ocurrio un error: " + e.getMessage());
                    System.out.println("*******Introduzcano una opcion correcta*******");
                }

            }//fin while

            if (a >= 1 && a <= 4) {
                System.out.print("Introduzca el primer numero: ");
                operando1 = entrada.nextInt();
                System.out.print("Introduzca el segundo numero: ");
                operando2 = entrada.nextInt();
            }//fin if

            switch (a) {
                case 1: {
                    a=0;
                    resultado = operando1 + operando2;
                    System.out.println("El resultado es: " + resultado);
                    break;
                }
                case 2: {
                    a=0;
                    resultado = operando1 - operando2;
                    System.out.println("El resultado es: " + resultado);
                    break;
                }
                case 3: {
                    a=0;
                    resultado = operando1 / operando2;
                    System.out.println("El resultado es: " + resultado);
                    break;
                }
                case 4: {
                    a=0;
                    resultado = operando1 * operando2;
                    System.out.println("El resultado es: " + resultado);
                    break;
                }
                case 5: {
                    a=0;
                    System.out.println("****Muchas gracias****");
                    condicion="No";
                    break;
                }
            }//fin swith
            entrada.nextLine();
        }///fin while
    }//fin main

    private static void menu(){

        System.out.println("****Aplicacion Calculadora****");
        System.out.println("1) Suma") ;
        System.out.println("2) Resta");
        System.out.println("3) Divicion");
        System.out.println("4) Multiplicacion");
        System.out.println("5) Salir");
        System.out.print("Opcion: " );
    }



}//fin clase
