package mundoPc;
import mundoPc.modelo.Computadora;
import mundoPc.modelo.Monitor;
import mundoPc.modelo.Raton;
import mundoPc.modelo.Teclado;
import mundoPc.servicio.Orden;

public class VentasComputadorasApp {
    public static void main(String[] args) {
        //Lenovo
        Raton ratonLenovo=new Raton("bluetooth","Lenovo");
        Teclado tecladoLenovo = new Teclado("Bluetooth", "Lenovo");
        Monitor monitorLenovo =new Monitor("Lenovo",27);
        Computadora computadoraLenovo =new Computadora("ComputadoraLenovo",monitorLenovo,tecladoLenovo,ratonLenovo);
        //Dell
        Monitor monitorDell=new Monitor("Dell",15);
        Teclado tecladoDell=new Teclado("USB","Dell");
        Raton ratonDell=new Raton("USB","Dell");
        Computadora computadoraDell=new Computadora("ComputadoraDell",monitorDell,tecladoDell,ratonDell);
        //Mac
        Monitor monitorMac=new Monitor("Mac",20);
        Teclado tecladoMac=new Teclado("USB","Mac");
        Raton ratonMac=new Raton("USB","Mac");
        Computadora computadoraMac=new Computadora("ComputadoraMac",monitorMac,tecladoMac,ratonMac);



        Orden orden1 = new Orden();
        orden1.agregarComputadora(computadoraLenovo);
        orden1.agregarComputadora(computadoraDell);
        orden1.mostrarOrden();

        Orden orden2 = new Orden();
        orden2.agregarComputadora(computadoraMac);
        orden2.mostrarOrden();
    }
}